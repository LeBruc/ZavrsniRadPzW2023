from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.views.generic import ListView
from main.models import Redatelj,Glumac,Studio,Osoblje,Reklama,Film,Serija
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

@login_required(login_url='/ulogiravanje')
def homepage(request):
    return render(request, "base_generic.html")
    
def registracija(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Racun kreiran za ' + user)
            return redirect('/ulogiravanje')

    context = { 'form' : form }
    return render(request, "registracija.html", context)

def ulogiravanje(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Username ili lozinka netocni')

    context = {}
    return render(request, "ulogiravanje.html", context)


@login_required(login_url='/ulogiravanje')
def odlogiravanje(request):
    logout(request)
    return redirect('/ulogiravanje')

class moviesearch(ListView):
    model = Film
    template_name = 'moviesearch.html'
    
    def get_queryset(self):
        query = self.request.GET.get("q")
        object_list = Film.objects.filter(film_ime__icontains=query)
        return object_list

# def moviesearch(request):
#     movies = Film.objects.filter(film_ime__icontains='t')

#     context = {'movies' : movies }

#     return render(request, 'moviesearch.html', context=context)


class RedateljList(ListView):
    model=Redatelj

class GlumacList(ListView):
    model=Glumac

class StudioList(ListView):
    model=Studio

class OsobljeList(ListView):
    model=Osoblje

class ReklamaList(ListView):
    model=Reklama

class FilmList(ListView):
    model=Film

class SerijaList(ListView):
    model=Serija